package com.chakra.bangla;

/** Colour palettes the user can pick from in the settings screen. */
public final class KeyboardTheme {
    public final String id;
    public final String name;
    public final int background;
    public final int key;
    public final int keySpecial;
    public final int keyPressed;
    public final int text;
    public final int textSpecial;
    public final int accent;       // wheel highlight / active shift
    public final int wheelBg;
    public final int wheelText;
    public final boolean light;

    private KeyboardTheme(String id, String name, int background, int key, int keySpecial,
                          int keyPressed, int text, int textSpecial, int accent,
                          int wheelBg, int wheelText, boolean light) {
        this.id = id;
        this.name = name;
        this.background = background;
        this.key = key;
        this.keySpecial = keySpecial;
        this.keyPressed = keyPressed;
        this.text = text;
        this.textSpecial = textSpecial;
        this.accent = accent;
        this.wheelBg = wheelBg;
        this.wheelText = wheelText;
        this.light = light;
    }

    public static final KeyboardTheme[] ALL = {
            new KeyboardTheme("dark", "Dark",
                    0xFF1B1B1B, 0xFF2E2E2E, 0xFF232323, 0xFF4A4A4A,
                    0xFFEDEDED, 0xFFB5B5B5, 0xFF26A69A, 0xFF2B2B2B, 0xFFFFFFFF, false),
            new KeyboardTheme("light", "Light",
                    0xFFD9DCE0, 0xFFFFFFFF, 0xFFC4C8CE, 0xFFB8BEC6,
                    0xFF202124, 0xFF4A4F57, 0xFF1A73E8, 0xFFF1F3F4, 0xFF202124, true),
            new KeyboardTheme("amoled", "AMOLED black",
                    0xFF000000, 0xFF141414, 0xFF0A0A0A, 0xFF333333,
                    0xFFFFFFFF, 0xFFAAAAAA, 0xFFFFB300, 0xFF1A1A1A, 0xFFFFFFFF, false),
            new KeyboardTheme("ocean", "Ocean",
                    0xFF0D2538, 0xFF17405E, 0xFF10314B, 0xFF2A6288,
                    0xFFE6F3FB, 0xFFA9CBE0, 0xFF4FC3F7, 0xFF133754, 0xFFFFFFFF, false),
            new KeyboardTheme("forest", "Forest",
                    0xFF14261A, 0xFF21402B, 0xFF1A3322, 0xFF35643F,
                    0xFFE8F5E9, 0xFFB2D8B7, 0xFF9CCC65, 0xFF1D3826, 0xFFFFFFFF, false),
            new KeyboardTheme("rose", "Rose",
                    0xFFF3D9E1, 0xFFFFF5F8, 0xFFE8BFCC, 0xFFDDA3B6,
                    0xFF4A1F2E, 0xFF7A3B50, 0xFFD81B60, 0xFFFFF0F4, 0xFF4A1F2E, true),
            new KeyboardTheme("sunset", "Sunset",
                    0xFF2A1420, 0xFF4A2336, 0xFF361A28, 0xFF7A3B55,
                    0xFFFFE9E0, 0xFFE0B3A6, 0xFFFF7043, 0xFF3C1D2E, 0xFFFFFFFF, false),
            new KeyboardTheme("lavender", "Lavender",
                    0xFFE6E0F5, 0xFFFFFFFF, 0xFFD0C7EA, 0xFFBDB1E0,
                    0xFF241A3D, 0xFF50427A, 0xFF7E57C2, 0xFFF6F3FD, 0xFF241A3D, true),
    };

    public static KeyboardTheme byId(String id) {
        if (id != null) {
            for (KeyboardTheme t : ALL) if (t.id.equals(id)) return t;
        }
        return ALL[0];
    }
}
