import com.chakra.bangla.*;
import java.util.*;

public class CoreTest {
    static int fails = 0;
    static void check(boolean ok, String msg) { if (!ok) { fails++; System.out.println("FAIL: " + msg); } }

    public static void main(String[] a) {
        // wheel math: 10 sectors, slot 0 at 12 o'clock, clockwise
        check(WheelMath.sectorAt(0, -50, 20, 10) == 0, "top -> 0");
        check(WheelMath.sectorAt(50, 0, 20, 10) == 2 || WheelMath.sectorAt(50, 0, 20, 10) == 3, "right -> ~2.5");
        check(WheelMath.sectorAt(0, 50, 20, 10) == 5, "bottom -> 5");
        check(WheelMath.sectorAt(-50, 0, 20, 10) == 7 || WheelMath.sectorAt(-50, 0, 20, 10) == 8, "left");
        check(WheelMath.sectorAt(5, 5, 20, 10) == -1, "centre");
        check(WheelMath.sectorAt(-1, -50, 20, 10) == 0, "slightly left of top -> 0");
        check(WheelMath.sectorAt(-20, -50, 20, 10) == 9, "up-left -> 9");
        Set<Integer> seen = new TreeSet<>();
        for (int d = 0; d < 360; d++) {
            double r = Math.toRadians(d);
            seen.add(WheelMath.sectorAt((float) (60 * Math.sin(r)), (float) (-60 * Math.cos(r)), 20, 10));
        }
        check(seen.size() == 10, "all 10 sectors reachable: " + seen);

        for (int layer = 0; layer <= 4; layer++) {
            List<List<Key>> rows = KeyboardLayouts.build(layer, "Done");
            check(rows.size() == 5, "layer " + layer + " has 5 rows");
            for (List<Key> r : rows) {
                float sum = 0;
                for (Key k : r) sum += k.weight;
                check(Math.abs(sum - 10f) < 0.01f, "layer " + layer + " row weight " + sum);
                for (Key k : r) if (k.hasWheel()) check(k.wheel.length == k.wheelLabels.length && k.wheel.length == 10, "wheel size " + k.label);
            }
        }
        Key ka = KeyboardLayouts.build(0, "Done").get(0).get(0);
        check(ka.text.equals("ক"), "first key ক");
        check(ka.wheel[0].equals("কা") && ka.wheel[6].equals("কে") && ka.wheel[8].equals("কো"), "ক wheel: " + Arrays.toString(ka.wheel));
        Key a1 = KeyboardLayouts.build(0, "Done").get(3).get(3);
        check(a1.label.equals("অ") && a1.wheel[0].equals("আ"), "vowel key");
        Key h = KeyboardLayouts.build(0, "Done").get(3).get(7);
        check(h.text.equals("্") && h.wheel[0].equals("্র"), "hasanta wheel");
        System.out.println(fails == 0 ? "ALL PASS" : fails + " FAILED");
        System.out.println(Arrays.toString(ka.wheelLabels));
        System.exit(fails);
    }
}
