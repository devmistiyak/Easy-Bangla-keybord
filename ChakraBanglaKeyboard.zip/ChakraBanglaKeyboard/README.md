# Chakra Bangla Keyboard

A Bangla (+ English) Android keyboard with a radial vowel-sign wheel, written from scratch
(plain Android framework APIs, no libraries, **minSdk 34 / Android 14 and up**).

## How typing works
* **Tap** a consonant -> types the plain consonant (ক).
* **Press** a consonant -> a wheel of vowel signs opens around it. **Slide** to a sector and
  release -> consonant + vowel sign (কা কি কী কু কূ কৃ কে কৈ কো কৌ).
* **অ** key wheel -> independent vowels (আ ই ঈ উ ঊ ঋ এ ঐ ও ঔ).
* **◌্** key: hasanta for conjuncts (ক ◌্ ষ = ক্ষ). Its wheel has ্র ্য ্ব ্ম ্ন ্ল ্ত ্ক র্ and ZWNJ.
  There is also a ready-made **ক্ষ** key.
* **⇧** in Bangla shows vowels, ং ঃ ঁ ৎ য় ৳, ZWNJ/ZWJ, Bangla digits and punctuation.
* **En / বাং** switches language, **?123** switches to numbers & symbols.
* Keys with a small dot have a wheel.

## Themes & settings
Open the app: 8 themes (Dark, Light, AMOLED, Ocean, Forest, Rose, Sunset, Lavender),
vibration, key sound, keyboard height, and a live typing test.

## Build the APK
**Option A – no installs (GitHub):** create a GitHub repo, upload this folder, open the
*Actions* tab -> *Build APK* -> download `ChakraBanglaKeyboard-debug-apk`. Install `app-debug.apk`.

**Option B – Android Studio:** *File -> Open* this folder, press *Run* (or
*Build -> Build APK(s)*). Output: `app/build/outputs/apk/debug/app-debug.apk`.

**Option C – command line:** with the Android SDK + JDK 17 + Gradle 8.7: `gradle assembleDebug`.

## Enable it on the phone
Open the app -> **1. Enable keyboard** -> switch on *Chakra Bangla Keyboard* -> **2. Choose Chakra Bangla**.

## Notes
* Android 4.1–4.4 phones without a Bangla system font show boxes. Put a Bangla `.ttf` at
  `app/src/main/assets/bangla.ttf` and the keyboard will use it automatically.
* Core logic tests (layout + wheel geometry, no Android needed): see `tests/CoreTest.java`.
* This is an independent implementation inspired by the wheel-typing idea; it contains no code
  or assets from other keyboards.
