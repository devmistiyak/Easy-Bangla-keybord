package com.chakra.bangla;

/** Geometry of the radial "chakra" wheel. Pure Java so it can be unit tested. */
public final class WheelMath {
    private WheelMath() {}

    /**
     * Which wheel slot is the finger over?
     *
     * @param dx       finger x minus wheel-centre x
     * @param dy       finger y minus wheel-centre y (screen coords, y grows downward)
     * @param innerR   radius of the centre "plain consonant" circle
     * @param sectors  number of slots in the ring (slot 0 is centred at 12 o'clock, clockwise)
     * @return -1 for the centre, otherwise 0..sectors-1
     */
    public static int sectorAt(float dx, float dy, float innerR, int sectors) {
        if (sectors <= 0) return -1;
        double dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < innerR) return -1;
        // angle clockwise from 12 o'clock, in degrees [0,360)
        double deg = Math.toDegrees(Math.atan2(dx, -dy));
        if (deg < 0) deg += 360.0;
        double size = 360.0 / sectors;
        int idx = (int) Math.floor((deg + size / 2.0) / size) % sectors;
        return idx;
    }

    /** Centre angle (radians, clockwise from 12 o'clock) of a slot. */
    public static double sectorCenterRad(int index, int sectors) {
        return Math.toRadians(index * (360.0 / sectors));
    }
}
