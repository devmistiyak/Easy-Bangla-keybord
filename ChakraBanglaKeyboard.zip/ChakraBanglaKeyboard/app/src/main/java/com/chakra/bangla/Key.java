package com.chakra.bangla;

/** One key on the keyboard. Pure data, no Android dependencies. */
public final class Key {
    public static final int ACT_TEXT = 0;     // commit {@link #text}
    public static final int ACT_SHIFT = 1;
    public static final int ACT_DELETE = 2;
    public static final int ACT_SPACE = 3;
    public static final int ACT_ENTER = 4;
    public static final int ACT_SYMBOLS = 5;  // go to ?123 layer
    public static final int ACT_LETTERS = 6;  // go back to letters
    public static final int ACT_LANG = 7;     // toggle Bangla <-> English

    public final String label;
    public final String text;
    public final int action;
    public final float weight;
    /** Wheel outputs (what is committed), same length as {@link #wheelLabels}; null = no wheel. */
    public final String[] wheel;
    public final String[] wheelLabels;
    /** Special (function) keys are drawn with the darker "special" colour. */
    public final boolean special;

    // Filled in by the view during layout (pixels).
    public float x, y, w, h;

    public Key(String label, String text, int action, float weight,
               String[] wheel, String[] wheelLabels, boolean special) {
        this.label = label;
        this.text = text;
        this.action = action;
        this.weight = weight;
        this.wheel = wheel;
        this.wheelLabels = wheelLabels;
        this.special = special;
    }

    public boolean hasWheel() {
        return wheel != null && wheel.length > 0;
    }

    public float centerX() { return x + w / 2f; }
    public float centerY() { return y + h / 2f; }
    public boolean contains(float px, float py) {
        return px >= x && px < x + w && py >= y && py < y + h;
    }
}
