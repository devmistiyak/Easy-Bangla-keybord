package com.chakra.bangla;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.util.TypedValue;
import android.view.View;

/** The round vowel-sign wheel that pops up when a consonant key is pressed. */
final class WheelView extends View {
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF oval = new RectF();

    private KeyboardTheme theme = KeyboardTheme.ALL[0];
    private String center = "";
    private String[] labels = new String[0];
    private int highlight = -1;
    private final float outerR;
    private final float innerR;

    WheelView(Context c, float outerR, float innerR, Typeface tf) {
        super(c);
        this.outerR = outerR;
        this.innerR = innerR;
        text.setTextAlign(Paint.Align.CENTER);
        if (tf != null) text.setTypeface(tf);
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeWidth(dp(1));
    }

    void setData(KeyboardTheme t, String centerLabel, String[] sectorLabels) {
        theme = t;
        center = centerLabel;
        labels = sectorLabels;
        highlight = -1;
        invalidate();
    }

    void setHighlight(int idx) {
        if (idx != highlight) {
            highlight = idx;
            invalidate();
        }
    }

    private float dp(float v) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v,
                getResources().getDisplayMetrics());
    }

    private float sp(float v) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v,
                getResources().getDisplayMetrics());
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float cx = getWidth() / 2f, cy = getHeight() / 2f;
        int n = Math.max(1, labels.length);
        float step = 360f / n;

        // outer disc
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(theme.wheelBg);
        canvas.drawCircle(cx, cy, outerR, fill);

        // highlighted wedge
        if (highlight >= 0) {
            oval.set(cx - outerR, cy - outerR, cx + outerR, cy + outerR);
            fill.setColor(theme.accent);
            canvas.drawArc(oval, -90f + (highlight - 0.5f) * step, step, true, fill);
        }

        // inner disc (plain consonant)
        fill.setColor(highlight < 0 ? theme.accent : theme.keySpecial);
        canvas.drawCircle(cx, cy, innerR, fill);

        // outlines + dividers
        line.setColor(theme.light ? 0x33000000 : 0x44FFFFFF);
        canvas.drawCircle(cx, cy, outerR, line);
        canvas.drawCircle(cx, cy, innerR, line);
        for (int i = 0; i < n; i++) {
            double a = Math.toRadians((i - 0.5) * step);
            float sx = cx + (float) (innerR * Math.sin(a));
            float sy = cy - (float) (innerR * Math.cos(a));
            float ex = cx + (float) (outerR * Math.sin(a));
            float ey = cy - (float) (outerR * Math.cos(a));
            canvas.drawLine(sx, sy, ex, ey, line);
        }

        // labels
        float mid = (innerR + outerR) / 2f;
        text.setTextSize(sp(n > 8 ? 17 : 19));
        for (int i = 0; i < labels.length; i++) {
            double a = WheelMath.sectorCenterRad(i, n);
            float lx = cx + (float) (mid * Math.sin(a));
            float ly = cy - (float) (mid * Math.cos(a));
            text.setColor(i == highlight ? onAccent() : theme.wheelText);
            drawCentered(canvas, labels[i], lx, ly);
        }
        text.setTextSize(sp(24));
        text.setColor(highlight < 0 ? onAccent() : theme.text);
        drawCentered(canvas, center, cx, cy);
    }

    private int onAccent() {
        // pick black/white text for the accent colour
        int c = theme.accent;
        int r = (c >> 16) & 0xFF, g = (c >> 8) & 0xFF, b = c & 0xFF;
        double lum = 0.299 * r + 0.587 * g + 0.114 * b;
        return lum > 150 ? 0xFF111111 : 0xFFFFFFFF;
    }

    private void drawCentered(Canvas canvas, String s, float x, float y) {
        Paint.FontMetrics fm = text.getFontMetrics();
        canvas.drawText(s, x, y - (fm.ascent + fm.descent) / 2f, text);
    }
}
