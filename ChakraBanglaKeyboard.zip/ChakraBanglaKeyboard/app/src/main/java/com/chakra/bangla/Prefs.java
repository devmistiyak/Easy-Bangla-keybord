package com.chakra.bangla;

import android.content.Context;
import android.content.SharedPreferences;

/** Thin wrapper around SharedPreferences. */
public final class Prefs {
    private static final String FILE = "chakra_prefs";
    private static final String K_THEME = "theme";
    private static final String K_HAPTIC = "haptic";
    private static final String K_SOUND = "sound";
    private static final String K_HEIGHT = "height_pct";
    private static final String K_LANG = "last_lang_bangla";

    private final SharedPreferences sp;

    public Prefs(Context c) {
        // The IME and the settings activity live in the same process, so MODE_PRIVATE is enough.
        sp = c.getApplicationContext().getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    public KeyboardTheme theme() { return KeyboardTheme.byId(sp.getString(K_THEME, "dark")); }
    public void setTheme(String id) { sp.edit().putString(K_THEME, id).apply(); }

    public boolean haptic() { return sp.getBoolean(K_HAPTIC, true); }
    public void setHaptic(boolean v) { sp.edit().putBoolean(K_HAPTIC, v).apply(); }

    public boolean sound() { return sp.getBoolean(K_SOUND, false); }
    public void setSound(boolean v) { sp.edit().putBoolean(K_SOUND, v).apply(); }

    /** Key height scale in percent, 80..130. */
    public int heightPct() { return sp.getInt(K_HEIGHT, 100); }
    public void setHeightPct(int v) { sp.edit().putInt(K_HEIGHT, Math.max(80, Math.min(130, v))).apply(); }

    public boolean lastLangBangla() { return sp.getBoolean(K_LANG, true); }
    public void setLastLangBangla(boolean v) { sp.edit().putBoolean(K_LANG, v).apply(); }
}
