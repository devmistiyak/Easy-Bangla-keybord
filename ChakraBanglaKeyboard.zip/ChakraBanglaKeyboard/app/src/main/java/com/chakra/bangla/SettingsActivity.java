package com.chakra.bangla;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.text.Editable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

/**
 * Launcher screen: enable/select the keyboard, pick a theme, tweak feedback + height, and try
 * typing in a live preview that uses exactly the same keyboard view as the real IME.
 */
public class SettingsActivity extends Activity implements KeyboardListener {
    private static final int UI_BG = 0xFFF2F4F7;
    private static final int UI_TEXT = 0xFF1F2328;
    private static final int UI_MUTED = 0xFF5F6872;
    private static final int UI_ACCENT = 0xFF1A73E8;

    private Prefs prefs;
    private TextView status1, status2;
    private EditText tryBox;
    private ChakraKeyboardView preview;
    private final List<SwatchView> swatches = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = new Prefs(this);
        setTitle("Chakra Bangla Keyboard");

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(UI_BG);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(20), dp(16), dp(24));
        scroll.addView(root, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView title = text("Chakra Bangla Keyboard", 24, UI_TEXT, true);
        root.addView(title);
        TextView sub = text("Type Bangla by pressing a consonant and sliding to a vowel sign.",
                14, UI_MUTED, false);
        sub.setPadding(0, dp(4), 0, dp(14));
        root.addView(sub);

        // ---- setup card
        LinearLayout setup = card(root, "Set up");
        status1 = text("", 14, UI_MUTED, false);
        setup.addView(status1);
        setup.addView(button("1. Enable keyboard", new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS));
            }
        }));
        status2 = text("", 14, UI_MUTED, false);
        status2.setPadding(0, dp(10), 0, 0);
        setup.addView(status2);
        setup.addView(button("2. Choose Chakra Bangla", new View.OnClickListener() {
            @Override public void onClick(View v) {
                InputMethodManager imm =
                        (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) imm.showInputMethodPicker();
            }
        }));

        // ---- try-it card
        LinearLayout tryCard = card(root, "Try it");
        tryBox = new EditText(this);
        tryBox.setHint("Type here...");
        tryBox.setMinLines(2);
        tryBox.setGravity(Gravity.TOP | Gravity.START);
        tryBox.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        tryBox.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        suppressSystemKeyboard(tryBox);
        tryCard.addView(tryBox, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        preview = new ChakraKeyboardView(this);
        preview.setKeyboardListener(this);
        preview.setLanguageBangla(prefs.lastLangBangla());
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        plp.topMargin = dp(10);
        tryCard.addView(preview, plp);
        TextView hint = text("Tap a consonant to type it. Press and slide into the wheel for "
                + "vowel signs. Keys with a dot have a wheel. ⇧ shows vowels, signs and digits.",
                12, UI_MUTED, false);
        hint.setPadding(0, dp(8), 0, 0);
        tryCard.addView(hint);

        // ---- theme card
        LinearLayout themeCard = card(root, "Theme");
        KeyboardTheme[] all = KeyboardTheme.ALL;
        LinearLayout row = null;
        for (int i = 0; i < all.length; i++) {
            if (i % 4 == 0) {
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                themeCard.addView(row, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            }
            row.addView(themeCell(all[i]), new LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        }

        // ---- feedback + size card
        LinearLayout opts = card(root, "Keyboard");
        opts.addView(check("Vibrate on keypress", prefs.haptic(),
                new CompoundButton.OnCheckedChangeListener() {
                    @Override public void onCheckedChanged(CompoundButton b, boolean on) {
                        prefs.setHaptic(on);
                    }
                }));
        opts.addView(check("Sound on keypress", prefs.sound(),
                new CompoundButton.OnCheckedChangeListener() {
                    @Override public void onCheckedChanged(CompoundButton b, boolean on) {
                        prefs.setSound(on);
                    }
                }));
        final TextView hLabel = text("", 14, UI_TEXT, false);
        hLabel.setPadding(0, dp(12), 0, 0);
        opts.addView(hLabel);
        SeekBar seek = new SeekBar(this);
        seek.setMax(50); // 80..130
        seek.setProgress(prefs.heightPct() - 80);
        hLabel.setText("Keyboard height: " + prefs.heightPct() + "%");
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean user) {
                prefs.setHeightPct(80 + p);
                hLabel.setText("Keyboard height: " + (80 + p) + "%");
                preview.applyPrefs();
            }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
        opts.addView(seek);

        setContentView(scroll);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshStatus();
        preview.applyPrefs();
    }

    private void refreshStatus() {
        boolean enabled = false, selected = false;
        try {
            InputMethodManager imm =
                    (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) {
                for (InputMethodInfo info : imm.getEnabledInputMethodList()) {
                    if (info.getPackageName().equals(getPackageName())) enabled = true;
                }
            }
            String def = Settings.Secure.getString(getContentResolver(),
                    Settings.Secure.DEFAULT_INPUT_METHOD);
            selected = def != null && def.startsWith(getPackageName() + "/");
        } catch (RuntimeException ignored) { }
        status1.setText(enabled ? "✅ Keyboard is enabled" : "⬜ Keyboard is not enabled yet");
        status2.setText(selected ? "✅ Chakra Bangla is your active keyboard"
                : "⬜ Not the active keyboard yet");
    }

    // ------------------------------------------------------------ KeyboardListener (preview)

    @Override
    public void onText(String s) {
        int a = Math.max(0, tryBox.getSelectionStart());
        int b = Math.max(0, tryBox.getSelectionEnd());
        int lo = Math.min(a, b), hi = Math.max(a, b);
        tryBox.getText().replace(lo, hi, s);
        tryBox.setSelection(lo + s.length());
    }

    @Override
    public void onDelete() {
        int a = Math.max(0, tryBox.getSelectionStart());
        int b = Math.max(0, tryBox.getSelectionEnd());
        int lo = Math.min(a, b), hi = Math.max(a, b);
        Editable e = tryBox.getText();
        if (hi > lo) {
            e.delete(lo, hi);
            tryBox.setSelection(lo);
        } else if (lo > 0) {
            e.delete(lo - 1, lo);
            tryBox.setSelection(lo - 1);
        }
    }

    @Override
    public void onEnter() {
        onText("\n");
    }

    @Override
    public void onLanguageChanged(boolean bangla) {
        prefs.setLastLangBangla(bangla);
    }

    // ------------------------------------------------------------ theme swatches

    private View themeCell(final KeyboardTheme t) {
        LinearLayout cell = new LinearLayout(this);
        cell.setOrientation(LinearLayout.VERTICAL);
        cell.setGravity(Gravity.CENTER_HORIZONTAL);
        cell.setPadding(dp(3), dp(6), dp(3), dp(6));
        final SwatchView sw = new SwatchView(this, t);
        swatches.add(sw);
        cell.addView(sw, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(58)));
        TextView name = text(t.name, 12, UI_TEXT, false);
        name.setGravity(Gravity.CENTER);
        name.setPadding(0, dp(4), 0, 0);
        cell.addView(name);
        cell.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                prefs.setTheme(t.id);
                preview.applyPrefs();
                for (SwatchView s : swatches) s.invalidate();
            }
        });
        return cell;
    }

    private final class SwatchView extends View {
        private final KeyboardTheme t;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();

        SwatchView(Context c, KeyboardTheme t) {
            super(c);
            this.t = t;
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight(), rad = dp(10);
            boolean sel = prefs.theme().id.equals(t.id);
            r.set(dp(2), dp(2), w - dp(2), h - dp(2));
            p.setStyle(Paint.Style.FILL);
            p.setColor(t.background);
            c.drawRoundRect(r, rad, rad, p);
            // three mini keys + accent
            float kw = (w - dp(24)) / 3f, kh = (h - dp(26)) / 2f;
            for (int row = 0; row < 2; row++) {
                for (int col = 0; col < 3; col++) {
                    p.setColor(row == 1 && col == 0 ? t.keySpecial : t.key);
                    float x = dp(8) + col * (kw + dp(4)), y = dp(8) + row * (kh + dp(4));
                    c.drawRoundRect(new RectF(x, y, x + kw, y + kh), dp(3), dp(3), p);
                }
            }
            p.setColor(t.accent);
            c.drawCircle(w - dp(14), h - dp(14), dp(4), p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(sel ? dp(3) : dp(1));
            p.setColor(sel ? UI_ACCENT : 0x33000000);
            c.drawRoundRect(r, rad, rad, p);
        }
    }

    // ------------------------------------------------------------ small UI helpers

    private LinearLayout card(LinearLayout parent, String heading) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(14), dp(16), dp(16));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFFFFFFFF);
        bg.setCornerRadius(dp(14));
        bg.setStroke(dp(1), 0x14000000);
        if (Build.VERSION.SDK_INT >= 16) c.setBackground(bg);
        else c.setBackgroundDrawable(bg);
        TextView h = text(heading, 16, UI_TEXT, true);
        h.setPadding(0, 0, 0, dp(8));
        c.addView(h);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(12);
        parent.addView(c, lp);
        return c;
    }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private Button button(String label, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        return b;
    }

    private CheckBox check(String label, boolean on, CompoundButton.OnCheckedChangeListener l) {
        CheckBox c = new CheckBox(this);
        c.setText(label);
        c.setTextColor(UI_TEXT);
        c.setChecked(on);
        c.setOnCheckedChangeListener(l);
        return c;
    }

    private void suppressSystemKeyboard(EditText et) {
        if (Build.VERSION.SDK_INT >= 21) {
            et.setShowSoftInputOnFocus(false);
        } else {
            try {
                Method m = EditText.class.getMethod("setSoftInputShownOnFocus", boolean.class);
                m.invoke(et, false);
            } catch (Exception ignored) { }
        }
    }

    private int dp(float v) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v,
                getResources().getDisplayMetrics()));
    }
}
