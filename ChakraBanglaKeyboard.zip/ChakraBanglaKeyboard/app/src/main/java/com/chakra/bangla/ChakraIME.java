package com.chakra.bangla;

import android.inputmethodservice.InputMethodService;
import android.os.Build;
import android.text.InputType;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;

/** The system-facing keyboard service. All typing goes through {@link KeyboardListener}. */
public class ChakraIME extends InputMethodService implements KeyboardListener {
    private ChakraKeyboardView view;
    private Prefs prefs;

    @Override
    public void onCreate() {
        super.onCreate();
        prefs = new Prefs(this);
    }

    @Override
    public View onCreateInputView() {
        view = new ChakraKeyboardView(this);
        view.setKeyboardListener(this);
        view.setLanguageBangla(prefs.lastLangBangla());
        return view;
    }

    /** No fullscreen "extract" editor in landscape; the keyboard stays compact. */
    @Override
    public boolean onEvaluateFullscreenMode() {
        return false;
    }

    @Override
    public void onStartInputView(EditorInfo info, boolean restarting) {
        super.onStartInputView(info, restarting);
        if (view == null) return;
        view.dismissWheel();
        view.applyPrefs();
        tintNavigationBar();

        boolean wantBangla = prefs.lastLangBangla();
        boolean numeric = false;
        int cls = info.inputType & InputType.TYPE_MASK_CLASS;
        int variation = info.inputType & InputType.TYPE_MASK_VARIATION;
        if (cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE
                || cls == InputType.TYPE_CLASS_DATETIME) {
            numeric = true;
        } else if (cls == InputType.TYPE_CLASS_TEXT) {
            if (variation == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
                    || variation == InputType.TYPE_TEXT_VARIATION_URI
                    || variation == InputType.TYPE_TEXT_VARIATION_PASSWORD
                    || variation == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                    || variation == InputType.TYPE_TEXT_VARIATION_WEB_EDIT_TEXT
                    || variation == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD) {
                wantBangla = false;
            }
        }
        view.setLanguageBangla(wantBangla);
        if (numeric) view.showSymbols();
        view.setEnterLabel(enterLabel(info));
    }

    @Override
    public void onFinishInputView(boolean finishingInput) {
        if (view != null) view.dismissWheel();
        super.onFinishInputView(finishingInput);
    }

    private String enterLabel(EditorInfo info) {
        if ((info.imeOptions & EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0) return "↵";
        switch (info.imeOptions & EditorInfo.IME_MASK_ACTION) {
            case EditorInfo.IME_ACTION_GO: return "Go";
            case EditorInfo.IME_ACTION_SEARCH: return "Search";
            case EditorInfo.IME_ACTION_SEND: return "Send";
            case EditorInfo.IME_ACTION_NEXT: return "Next";
            case EditorInfo.IME_ACTION_DONE: return "Done";
            default: return "↵";
        }
    }

    private void tintNavigationBar() {
        if (Build.VERSION.SDK_INT < 21) return;
        try {
            Window w = getWindow().getWindow();
            if (w == null) return;
            w.setNavigationBarColor(prefs.theme().background);
            if (Build.VERSION.SDK_INT >= 26) {
                View decor = w.getDecorView();
                int flags = decor.getSystemUiVisibility();
                if (prefs.theme().light) flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                else flags &= ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                decor.setSystemUiVisibility(flags);
            }
        } catch (RuntimeException ignored) {
            // cosmetic only
        }
    }

    // ------------------------------------------------------------ KeyboardListener

    @Override
    public void onText(String text) {
        InputConnection ic = getCurrentInputConnection();
        if (ic != null) ic.commitText(text, 1);
    }

    @Override
    public void onDelete() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        CharSequence selected = ic.getSelectedText(0);
        if (selected != null && selected.length() > 0) {
            ic.commitText("", 1);
            return;
        }
        CharSequence before = ic.getTextBeforeCursor(1, 0);
        if (before == null || before.length() == 0) {
            // Editor doesn't expose text (or is empty): fall back to a real DEL key press.
            sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL);
        } else {
            ic.deleteSurroundingText(1, 0);
        }
    }

    @Override
    public void onEnter() {
        InputConnection ic = getCurrentInputConnection();
        EditorInfo info = getCurrentInputEditorInfo();
        if (ic == null) return;
        int action = info == null ? EditorInfo.IME_ACTION_NONE
                : info.imeOptions & EditorInfo.IME_MASK_ACTION;
        boolean noAction = info == null
                || (info.imeOptions & EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
                || action == EditorInfo.IME_ACTION_NONE
                || action == EditorInfo.IME_ACTION_UNSPECIFIED;
        if (noAction) sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER);
        else ic.performEditorAction(action);
    }

    @Override
    public void onLanguageChanged(boolean bangla) {
        prefs.setLastLangBangla(bangla);
    }
}
