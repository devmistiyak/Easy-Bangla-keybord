package com.chakra.bangla;

/** Receives typing events from {@link ChakraKeyboardView}. */
public interface KeyboardListener {
    void onText(String text);
    void onDelete();
    void onEnter();
    /** Language was toggled (true = Bangla). */
    void onLanguageChanged(boolean bangla);
}
