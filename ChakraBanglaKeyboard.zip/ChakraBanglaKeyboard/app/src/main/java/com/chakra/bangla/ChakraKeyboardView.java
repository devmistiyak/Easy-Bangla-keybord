package com.chakra.bangla;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.media.AudioManager;
import android.os.Handler;
import android.os.Looper;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.widget.PopupWindow;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * The whole keyboard: draws the keys, handles touch, and shows the vowel-sign wheel.
 *
 * Typing: tap a consonant = plain consonant. Press a consonant, slide into a sector of the
 * wheel and release = consonant + vowel sign.
 */
public class ChakraKeyboardView extends View {
    private static final int ROWS = 5;
    private static final long WHEEL_DELAY_MS = 90;
    private static final long REPEAT_FIRST_MS = 380;
    private static final long REPEAT_MS = 55;
    private static final long DOUBLE_TAP_MS = 400;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Paint keyPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();

    private KeyboardListener listener;
    private KeyboardTheme theme = KeyboardTheme.ALL[0];
    private Prefs prefs;
    private Typeface typeface;

    private boolean bangla = true;
    private boolean symbols = false;
    private int shift = 0; // 0 off, 1 once, 2 caps-lock (English only)
    private long lastShiftTap = 0;
    private String enterLabel = "↵";

    private List<List<Key>> rows = new ArrayList<>();
    private int builtLayer = -1;
    private String builtEnter = null;

    private final Map<Integer, Pointer> pointers = new HashMap<>();
    private Pointer wheelOwner = null;
    private PopupWindow wheelPopup;
    private WheelView wheelView;
    private final float wheelOuterR;
    private final float wheelInnerR;

    private static final class Pointer {
        final int id;
        final Key key;
        int sel = -1;
        boolean wheelShown = false;
        Runnable showWheel;
        Runnable repeat;

        Pointer(int id, Key key) {
            this.id = id;
            this.key = key;
        }
    }

    public ChakraKeyboardView(Context context) {
        this(context, null);
    }

    public ChakraKeyboardView(Context context, AttributeSet attrs) {
        super(context, attrs);
        prefs = new Prefs(context);
        wheelOuterR = dp(94);
        wheelInnerR = dp(30);
        try {
            // Optional: drop a Bangla font at app/src/main/assets/bangla.ttf to support very old
            // devices that ship without one. Falls back to the system font.
            typeface = Typeface.createFromAsset(context.getAssets(), "bangla.ttf");
        } catch (Exception ignored) {
            typeface = null;
        }
        if (typeface != null) textPaint.setTypeface(typeface);
        textPaint.setTextAlign(Paint.Align.CENTER);
        setSoundEffectsEnabled(false);
        applyPrefs();
        rebuildIfNeeded();
    }

    // ------------------------------------------------------------------ public API

    public void setKeyboardListener(KeyboardListener l) { listener = l; }

    /** Re-read theme / height from preferences. Call whenever the keyboard is (re)shown. */
    public void applyPrefs() {
        theme = prefs.theme();
        requestLayout();
        invalidate();
    }

    public void setLanguageBangla(boolean b) {
        bangla = b;
        shift = 0;
        symbols = false;
        rebuildIfNeeded();
        invalidate();
    }

    public boolean isBangla() { return bangla; }

    /** Jump to the number/symbol layer (used for number and phone fields). */
    public void showSymbols() {
        symbols = true;
        shift = 0;
        rebuildIfNeeded();
        invalidate();
    }

    public void setEnterLabel(String label) {
        enterLabel = label;
        rebuildIfNeeded();
        invalidate();
    }

    public void dismissWheel() {
        for (Pointer p : pointers.values()) cancelRunnables(p);
        pointers.clear();
        hideWheel();
        invalidate();
    }

    // ------------------------------------------------------------------ layout

    private int currentLayer() {
        if (symbols) return KeyboardLayouts.LAYER_SYMBOLS;
        if (bangla) return shift != 0 ? KeyboardLayouts.LAYER_BANGLA_EXTRA : KeyboardLayouts.LAYER_BANGLA;
        return shift != 0 ? KeyboardLayouts.LAYER_ENGLISH_UPPER : KeyboardLayouts.LAYER_ENGLISH;
    }

    private void rebuildIfNeeded() {
        int layer = currentLayer();
        if (layer == builtLayer && enterLabel.equals(builtEnter)) return;
        rows = KeyboardLayouts.build(layer, enterLabel);
        builtLayer = layer;
        builtEnter = enterLabel;
        layoutKeys(getWidth(), getHeight());
    }

    private float keyHeightPx() {
        boolean land = getResources().getConfiguration().orientation
                == Configuration.ORIENTATION_LANDSCAPE;
        float base = land ? 40f : 50f;
        return dp(base) * prefs.heightPct() / 100f;
    }

    @Override
    protected void onMeasure(int widthSpec, int heightSpec) {
        int w = MeasureSpec.getSize(widthSpec);
        if (w <= 0) {
            DisplayMetrics dm = getResources().getDisplayMetrics();
            w = dm.widthPixels;
        }
        int h = (int) (keyHeightPx() * ROWS + dp(8));
        setMeasuredDimension(w, h);
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        layoutKeys(w, h);
    }

    private void layoutKeys(int w, int h) {
        if (w <= 0 || h <= 0 || rows.isEmpty()) return;
        float padX = dp(2), padY = dp(4);
        float rowH = (h - 2 * padY) / rows.size();
        float availW = w - 2 * padX;
        for (int r = 0; r < rows.size(); r++) {
            List<Key> row = rows.get(r);
            float total = 0;
            for (Key k : row) total += k.weight;
            float x = padX;
            for (Key k : row) {
                float kw = availW * k.weight / total;
                k.x = x;
                k.y = padY + r * rowH;
                k.w = kw;
                k.h = rowH;
                x += kw;
            }
        }
    }

    // ------------------------------------------------------------------ drawing

    @Override
    protected void onDraw(Canvas canvas) {
        canvas.drawColor(theme.background);
        float gap = dp(2.5f);
        float radius = dp(6);
        for (List<Key> row : rows) {
            for (Key k : row) {
                if (k.action == KeyboardLayouts.ACT_SPACER) continue;
                boolean pressed = isPressed(k);
                int color = pressed ? theme.keyPressed : (k.special ? theme.keySpecial : theme.key);
                boolean activeShift = k.action == Key.ACT_SHIFT && shift != 0;
                if (activeShift) color = theme.accent;

                rect.set(k.x + gap, k.y + gap, k.x + k.w - gap, k.y + k.h - gap);
                keyPaint.setStyle(Paint.Style.FILL);
                keyPaint.setColor(color);
                canvas.drawRoundRect(rect, radius, radius, keyPaint);

                drawLabel(canvas, k, activeShift);

                if (k.hasWheel()) {
                    // small dot: "this key has a wheel"
                    keyPaint.setColor(theme.textSpecial);
                    keyPaint.setAlpha(150);
                    canvas.drawCircle(rect.right - dp(5), rect.top + dp(5), dp(1.6f), keyPaint);
                    keyPaint.setAlpha(255);
                }
                if (k.action == Key.ACT_SHIFT && shift == 2) {
                    keyPaint.setColor(onAccent());
                    canvas.drawRect(rect.centerX() - dp(7), rect.bottom - dp(7),
                            rect.centerX() + dp(7), rect.bottom - dp(5), keyPaint);
                }
            }
        }
    }

    private void drawLabel(Canvas canvas, Key k, boolean activeShift) {
        String label = k.label;
        float size;
        int color;
        if (k.action == Key.ACT_SPACE) {
            label = symbols ? "" : (bangla ? "বাংলা" : "English");
            size = sp(13);
            color = theme.textSpecial;
        } else if (k.action == Key.ACT_ENTER) {
            size = sp(14);
            color = theme.textSpecial;
        } else if (k.special) {
            size = (label.length() > 2) ? sp(13) : sp(18);
            color = activeShift ? onAccent() : theme.textSpecial;
        } else {
            size = sp(bangla && !symbols ? 22 : 21);
            color = theme.text;
        }
        if (label.isEmpty()) return;
        textPaint.setTextSize(size);
        textPaint.setColor(color);
        float maxW = k.w - dp(8);
        float tw = textPaint.measureText(label);
        if (tw > maxW) textPaint.setTextSize(size * maxW / tw);
        Paint.FontMetrics fm = textPaint.getFontMetrics();
        canvas.drawText(label, k.x + k.w / 2f, k.y + k.h / 2f - (fm.ascent + fm.descent) / 2f,
                textPaint);
    }

    private int onAccent() {
        int c = theme.accent;
        double lum = 0.299 * ((c >> 16) & 0xFF) + 0.587 * ((c >> 8) & 0xFF) + 0.114 * (c & 0xFF);
        return lum > 150 ? 0xFF111111 : 0xFFFFFFFF;
    }

    private boolean isPressed(Key k) {
        for (Pointer p : pointers.values()) if (p.key == k) return true;
        return false;
    }

    // ------------------------------------------------------------------ touch

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        switch (ev.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN: {
                int i = ev.getActionIndex();
                onDown(ev.getPointerId(i), ev.getX(i), ev.getY(i));
                break;
            }
            case MotionEvent.ACTION_MOVE:
                for (int i = 0; i < ev.getPointerCount(); i++) {
                    onMove(ev.getPointerId(i), ev.getX(i), ev.getY(i));
                }
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP: {
                int i = ev.getActionIndex();
                onUp(ev.getPointerId(i));
                break;
            }
            case MotionEvent.ACTION_CANCEL:
                dismissWheel();
                break;
            default:
                break;
        }
        return true;
    }

    private Key keyAt(float x, float y) {
        for (List<Key> row : rows) {
            for (Key k : row) {
                if (k.action != KeyboardLayouts.ACT_SPACER && k.contains(x, y)) return k;
            }
        }
        return null;
    }

    private void onDown(int id, float x, float y) {
        Key key = keyAt(x, y);
        if (key == null) return;
        final Pointer p = new Pointer(id, key);
        pointers.put(id, p);
        feedback(key);
        invalidate();

        if (key.hasWheel()) {
            p.showWheel = new Runnable() {
                @Override public void run() { showWheel(p); }
            };
            handler.postDelayed(p.showWheel, WHEEL_DELAY_MS);
        } else if (key.action == Key.ACT_DELETE) {
            doDelete();
            p.repeat = new Runnable() {
                @Override public void run() {
                    doDelete();
                    handler.postDelayed(this, REPEAT_MS);
                }
            };
            handler.postDelayed(p.repeat, REPEAT_FIRST_MS);
        }
    }

    private void onMove(int id, float x, float y) {
        Pointer p = pointers.get(id);
        if (p == null || !p.key.hasWheel()) return;
        int sel = WheelMath.sectorAt(x - p.key.centerX(), y - p.key.centerY(),
                wheelInnerR, p.key.wheel.length);
        if (sel != p.sel) {
            p.sel = sel;
            if (sel >= 0 && !p.wheelShown) showWheel(p); // fast flick: no need to wait
            if (wheelOwner == p && wheelView != null) wheelView.setHighlight(sel);
        }
    }

    private void onUp(int id) {
        Pointer p = pointers.remove(id);
        if (p == null) return;
        cancelRunnables(p);
        Key k = p.key;
        if (wheelOwner == p) hideWheel();

        switch (k.action) {
            case Key.ACT_TEXT:
                if (k.hasWheel() && p.sel >= 0) commit(k.wheel[p.sel]);
                else commit(k.text);
                break;
            case Key.ACT_SPACE:
                commit(" ");
                break;
            case Key.ACT_ENTER:
                if (listener != null) listener.onEnter();
                break;
            case Key.ACT_SHIFT:
                onShift();
                break;
            case Key.ACT_SYMBOLS:
                symbols = true;
                shift = 0;
                relayout();
                break;
            case Key.ACT_LETTERS:
                symbols = false;
                relayout();
                break;
            case Key.ACT_LANG:
                bangla = !bangla;
                shift = 0;
                symbols = false;
                relayout();
                prefs.setLastLangBangla(bangla);
                if (listener != null) listener.onLanguageChanged(bangla);
                break;
            default: // delete handled on down, spacer ignored
                break;
        }
        invalidate();
    }

    private void commit(String s) {
        if (listener != null && s != null && !s.isEmpty()) listener.onText(s);
        if (shift == 1) { // one-shot shift
            shift = 0;
            relayout();
        }
    }

    private void doDelete() {
        if (listener != null) listener.onDelete();
    }

    private void onShift() {
        long now = System.currentTimeMillis();
        if (bangla) {
            shift = shift == 0 ? 1 : 0;
        } else if (shift == 0) {
            shift = 1;
        } else if (shift == 1 && now - lastShiftTap < DOUBLE_TAP_MS) {
            shift = 2;
        } else {
            shift = 0;
        }
        lastShiftTap = now;
        relayout();
    }

    private void relayout() {
        rebuildIfNeeded();
        invalidate();
    }

    private void cancelRunnables(Pointer p) {
        if (p.showWheel != null) handler.removeCallbacks(p.showWheel);
        if (p.repeat != null) handler.removeCallbacks(p.repeat);
    }

    // ------------------------------------------------------------------ feedback

    private void feedback(Key k) {
        if (prefs.haptic()) {
            performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP,
                    HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING
                            | HapticFeedbackConstants.FLAG_IGNORE_VIEW_SETTING);
        }
        if (prefs.sound()) {
            AudioManager am = (AudioManager) getContext().getSystemService(Context.AUDIO_SERVICE);
            if (am != null) {
                int fx = AudioManager.FX_KEYPRESS_STANDARD;
                if (k.action == Key.ACT_SPACE) fx = AudioManager.FX_KEYPRESS_SPACEBAR;
                else if (k.action == Key.ACT_DELETE) fx = AudioManager.FX_KEYPRESS_DELETE;
                else if (k.action == Key.ACT_ENTER) fx = AudioManager.FX_KEYPRESS_RETURN;
                am.playSoundEffect(fx, 0.6f);
            }
        }
    }

    // ------------------------------------------------------------------ wheel popup

    private void showWheel(Pointer p) {
        if (!pointers.containsKey(p.id) || p.wheelShown) return;
        if (wheelOwner != null && wheelOwner != p) hideWheel();
        try {
            if (wheelView == null) {
                wheelView = new WheelView(getContext(), wheelOuterR, wheelInnerR, typeface);
            }
            int size = (int) (wheelOuterR * 2 + dp(8));
            if (wheelPopup == null) {
                wheelPopup = new PopupWindow(wheelView, size, size);
                wheelPopup.setTouchable(false);
                wheelPopup.setFocusable(false);
                wheelPopup.setClippingEnabled(false);
            }
            wheelView.setData(theme, p.key.label, p.key.wheelLabels);
            wheelView.setHighlight(p.sel);

            int[] loc = new int[2];
            getLocationOnScreen(loc);
            int screenW = getResources().getDisplayMetrics().widthPixels;
            int x = (int) (loc[0] + p.key.centerX() - size / 2f);
            int y = (int) (loc[1] + p.key.centerY() - size / 2f);
            x = Math.max(0, Math.min(screenW - size, x));

            if (wheelPopup.isShowing()) wheelPopup.update(x, y, size, size);
            else wheelPopup.showAtLocation(this, Gravity.NO_GRAVITY, x, y);
            wheelOwner = p;
            p.wheelShown = true;
        } catch (RuntimeException e) {
            // Window token problems etc.: typing still works, just without the visual wheel.
            wheelOwner = null;
        }
    }

    private void hideWheel() {
        if (wheelPopup != null && wheelPopup.isShowing()) {
            try { wheelPopup.dismiss(); } catch (RuntimeException ignored) { }
        }
        wheelOwner = null;
    }

    @Override
    protected void onDetachedFromWindow() {
        dismissWheel();
        super.onDetachedFromWindow();
    }

    // ------------------------------------------------------------------ units

    private float dp(float v) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v,
                getResources().getDisplayMetrics());
    }

    private float sp(float v) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v,
                getResources().getDisplayMetrics());
    }
}
