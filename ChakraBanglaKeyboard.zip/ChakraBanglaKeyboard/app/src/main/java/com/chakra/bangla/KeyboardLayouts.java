package com.chakra.bangla;

import java.util.ArrayList;
import java.util.List;

/**
 * Builds the key grids. Pure Java (no Android classes) so it can be unit tested.
 *
 * Bangla typing model ("chakra"/wheel): every consonant key types the plain consonant when
 * tapped. Pressing it opens a wheel of vowel signs (kar) around the key; slide to a sector and
 * release to type consonant + vowel sign in one gesture.
 */
public final class KeyboardLayouts {
    private KeyboardLayouts() {}

    public static final int LAYER_BANGLA = 0;
    public static final int LAYER_BANGLA_EXTRA = 1; // shift: vowels, signs, digits
    public static final int LAYER_SYMBOLS = 2;
    public static final int LAYER_ENGLISH = 3;
    public static final int LAYER_ENGLISH_UPPER = 4;

    /** Spacer: empty slot that takes width but is not drawn / not pressable. */
    public static final int ACT_SPACER = 8;

    /** Vowel signs in wheel order, clockwise from 12 o'clock. */
    public static final String[] KARS = {
            "া", // া
            "ি", // ি
            "ী", // ী
            "ু", // ু
            "ূ", // ূ
            "ৃ", // ৃ
            "ে", // ে
            "ৈ", // ৈ
            "ো", // ো
            "ৌ"  // ৌ
    };

    /** Independent vowels for the অ wheel, clockwise from 12 o'clock. */
    public static final String[] VOWELS = {
            "আ", "ই", "ঈ", "উ", "ঊ", "ঋ", "এ", "ঐ", "ও", "ঔ"
    };

    /** Items on the hasanta (conjunct) key wheel. */
    public static final String[] CONJUNCTS = {
            "্র", // ্র  ra-phala
            "্য", // ্য  ya-phala
            "্ব", // ্ব
            "্ম", // ্ম
            "্ন", // ্ন
            "্ল", // ্ল
            "্ত", // ্ত
            "্ক", // ্ক
            "র্", // র্  reph
            "‌"        // ZWNJ (breaks a conjunct)
    };

    private static final String DOTTED = "◌"; // ◌

    public static List<List<Key>> build(int layer, String enterLabel) {
        switch (layer) {
            case LAYER_BANGLA_EXTRA: return bnExtra(enterLabel);
            case LAYER_SYMBOLS: return symbols(enterLabel);
            case LAYER_ENGLISH: return english(false, enterLabel);
            case LAYER_ENGLISH_UPPER: return english(true, enterLabel);
            case LAYER_BANGLA:
            default: return bangla(enterLabel);
        }
    }

    // ---------------------------------------------------------------- Bangla

    private static List<List<Key>> bangla(String enter) {
        List<List<Key>> rows = new ArrayList<>();
        rows.add(consonantRow("ক", "খ", "গ", "ঘ", "ঙ", "চ", "ছ", "জ", "ঝ", "ঞ"));
        rows.add(consonantRow("ট", "ঠ", "ড", "ঢ", "ণ", "ত", "থ", "দ", "ধ", "ন"));
        rows.add(consonantRow("প", "ফ", "ব", "ভ", "ম", "য", "র", "ল", "শ", "ষ"));

        List<Key> r4 = new ArrayList<>();
        r4.add(fn("⇧", Key.ACT_SHIFT, 1.5f));
        r4.add(consonant("স"));
        r4.add(consonant("হ"));
        r4.add(vowelKey());
        r4.add(consonant("ড়"));
        r4.add(consonant("ঢ়"));
        r4.add(plain("ক্ষ"));
        r4.add(hasantaKey());
        r4.add(fn("⌫", Key.ACT_DELETE, 1.5f));
        rows.add(r4);

        rows.add(bottom("En", true, "।", enter));
        return rows;
    }

    private static List<List<Key>> bnExtra(String enter) {
        List<List<Key>> rows = new ArrayList<>();
        rows.add(plainRow("অ", "আ", "ই", "ঈ", "উ", "ঊ", "ঋ", "এ", "ঐ", "ও"));
        List<Key> r2 = new ArrayList<>();
        for (String s : new String[]{"ঔ", "ং", "ঃ", "ঁ", "ৎ", "য়", "৳", "ঽ"}) r2.add(plain(s));
        r2.add(new Key("ZWNJ", "‌", Key.ACT_TEXT, 1f, null, null, true));
        r2.add(new Key("ZWJ", "‍", Key.ACT_TEXT, 1f, null, null, true));
        rows.add(r2);
        rows.add(plainRow("১", "২", "৩", "৪", "৫", "৬", "৭", "৮", "৯", "০"));

        List<Key> r4 = new ArrayList<>();
        r4.add(fn("⇧", Key.ACT_SHIFT, 1.5f));
        for (String s : new String[]{"!", "?", ";", ":", "-", "(", ")"}) r4.add(plain(s));
        r4.add(fn("⌫", Key.ACT_DELETE, 1.5f));
        rows.add(r4);

        rows.add(bottom("En", true, "।", enter));
        return rows;
    }

    private static Key consonant(String c) {
        String[] out = new String[KARS.length];
        String[] lab = new String[KARS.length];
        for (int i = 0; i < KARS.length; i++) {
            out[i] = c + KARS[i];
            lab[i] = c + KARS[i];
        }
        return new Key(c, c, Key.ACT_TEXT, 1f, out, lab, false);
    }

    private static List<Key> consonantRow(String... cs) {
        List<Key> r = new ArrayList<>();
        for (String c : cs) r.add(consonant(c));
        return r;
    }

    /** The "অ" key: tap = অ, wheel = the other independent vowels. */
    private static Key vowelKey() {
        return new Key("অ", "অ", Key.ACT_TEXT, 1f, VOWELS.clone(), VOWELS.clone(), false);
    }

    private static Key hasantaKey() {
        String[] labels = new String[CONJUNCTS.length];
        for (int i = 0; i < labels.length; i++) {
            String c = CONJUNCTS[i];
            labels[i] = c.equals("‌") ? "ZWNJ"
                    : (c.endsWith("্") ? c : DOTTED + c);
        }
        return new Key(DOTTED + "্", "্", Key.ACT_TEXT, 1f,
                CONJUNCTS.clone(), labels, true);
    }

    // --------------------------------------------------------------- Symbols

    private static List<List<Key>> symbols(String enter) {
        List<List<Key>> rows = new ArrayList<>();
        rows.add(plainRow("1", "2", "3", "4", "5", "6", "7", "8", "9", "0"));
        rows.add(plainRow("@", "#", "$", "%", "&", "*", "-", "+", "(", ")"));
        rows.add(plainRow("!", "\"", "'", ":", ";", "/", "?", "_", "=", "~"));
        List<Key> r4 = new ArrayList<>();
        for (String s : new String[]{"[", "]", "{", "}", "<", ">", "\\", "|"}) r4.add(plain(s));
        r4.add(fn("⌫", Key.ACT_DELETE, 2f));
        rows.add(r4);
        rows.add(bottom(null, false, ".", enter));
        return rows;
    }

    // --------------------------------------------------------------- English

    private static List<List<Key>> english(boolean upper, String enter) {
        List<List<Key>> rows = new ArrayList<>();
        rows.add(plainRow("1", "2", "3", "4", "5", "6", "7", "8", "9", "0"));
        rows.add(letterRow(upper, "qwertyuiop"));
        List<Key> r2 = new ArrayList<>();
        r2.add(spacer(0.5f));
        r2.addAll(letterRow(upper, "asdfghjkl"));
        r2.add(spacer(0.5f));
        rows.add(r2);
        List<Key> r3 = new ArrayList<>();
        r3.add(fn("⇧", Key.ACT_SHIFT, 1.5f));
        r3.addAll(letterRow(upper, "zxcvbnm"));
        r3.add(fn("⌫", Key.ACT_DELETE, 1.5f));
        rows.add(r3);
        rows.add(bottom("বাং", false, ".", enter));
        return rows;
    }

    private static List<Key> letterRow(boolean upper, String letters) {
        List<Key> r = new ArrayList<>();
        for (int i = 0; i < letters.length(); i++) {
            String s = String.valueOf(letters.charAt(i));
            if (upper) s = s.toUpperCase();
            r.add(plain(s));
        }
        return r;
    }

    // ---------------------------------------------------------------- shared

    /** Bottom row. langLabel == null means "ABC" (back to letters, used by symbols). */
    private static List<Key> bottom(String langLabel, boolean bangla, String endPunct, String enter) {
        List<Key> r = new ArrayList<>();
        if (langLabel == null) {
            r.add(fn("ABC", Key.ACT_LETTERS, 1.6f));
            r.add(plain(","));
        } else {
            r.add(fn("?123", Key.ACT_SYMBOLS, 1.3f));
            r.add(fn(langLabel, Key.ACT_LANG, 1.3f));
            r.add(plain(","));
        }
        r.add(new Key("", " ", Key.ACT_SPACE, langLabel == null ? 4.9f : 3.9f, null, null, false));
        r.add(plain(endPunct));
        r.add(fn(enter, Key.ACT_ENTER, 1.5f));
        return r;
    }

    private static Key plain(String s) {
        return new Key(s, s, Key.ACT_TEXT, 1f, null, null, false);
    }

    private static List<Key> plainRow(String... ss) {
        List<Key> r = new ArrayList<>();
        for (String s : ss) r.add(plain(s));
        return r;
    }

    private static Key fn(String label, int action, float weight) {
        return new Key(label, "", action, weight, null, null, true);
    }

    private static Key spacer(float weight) {
        return new Key("", "", ACT_SPACER, weight, null, null, false);
    }
}
